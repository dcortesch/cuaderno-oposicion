# Cuaderno de Oposición — Matemáticas Secundaria (Andalucía)

Sitio de navegación generado a partir del Estado Maestro y el material real en Google Drive.

## Publicarlo en GitHub Pages (una vez)

1. Crea un repositorio nuevo en GitHub (puede ser privado o público — si el temario no debe ser público, usa **privado** y activa Pages solo si tu plan de GitHub lo permite en repos privados; si no, usa público).
2. Sube estos archivos manteniendo la estructura de carpetas:
   ```
   index.html
   assets/style.css
   temas/t04.html
   ```
3. En el repositorio → **Settings → Pages** → Source: rama `main`, carpeta `/root`.
4. GitHub te da una URL tipo `https://tu-usuario.github.io/nombre-repo/`.

## Actualizarlo cada semana

Cuando termines de elaborar el material de una semana nueva, pídele a Claude:

> "He terminado el T03 (semana 2 del mes 1), actualiza el sitio."

Claude:
1. Lee el documento nuevo en Drive.
2. Genera `temas/t03.html` siguiendo la misma plantilla visual.
3. Actualiza la fila correspondiente en `index.html` (de "Pendiente" a "Elaborado", o a "Dominado" si ya diste evidencia de recuperación cronometrada).
4. Añade una línea al registro de actualizaciones al final del index.

Vuelves a subir los archivos cambiados a GitHub (o usas `git push` si trabajas con el repo clonado localmente) y la URL se actualiza sola.

## Estructura de archivos

```
/
├── index.html          ← página principal, índice de los 9 meses
├── assets/
│   └── style.css        ← estilos compartidos por todas las páginas
└── temas/
    └── t04.html          ← página individual por tema, mismo patrón para futuros temas
```
